class Demo
{
    public static void main(String Arg[])
    {
        System.out.println("Jay Ganesh...");
    }
}

